﻿
namespace GametdbWiiAndGcArtDownloader
{
    partial class DownloadWiiGameCubeArtHelper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_wiitdbTextFile = new System.Windows.Forms.Label();
            this.textBox_wiitdbTextFile = new System.Windows.Forms.TextBox();
            this.btn_browse_wiitdbTextFile = new System.Windows.Forms.Button();
            this.btn_browse_destination = new System.Windows.Forms.Button();
            this.textBox_destination = new System.Windows.Forms.TextBox();
            this.label_destination = new System.Windows.Forms.Label();
            this.btn_downloadAllArts = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_wiitdbTextFile
            // 
            this.label_wiitdbTextFile.AutoSize = true;
            this.label_wiitdbTextFile.Location = new System.Drawing.Point(14, 17);
            this.label_wiitdbTextFile.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_wiitdbTextFile.Name = "label_wiitdbTextFile";
            this.label_wiitdbTextFile.Size = new System.Drawing.Size(161, 13);
            this.label_wiitdbTextFile.TabIndex = 16;
            this.label_wiitdbTextFile.Text = "Select \"wiitdb.txt\" text document";
            this.label_wiitdbTextFile.UseWaitCursor = true;
            this.label_wiitdbTextFile.Click += new System.EventHandler(this.label_wiitdbTextFile_Click);
            // 
            // textBox_wiitdbTextFile
            // 
            this.textBox_wiitdbTextFile.Location = new System.Drawing.Point(15, 41);
            this.textBox_wiitdbTextFile.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_wiitdbTextFile.Name = "textBox_wiitdbTextFile";
            this.textBox_wiitdbTextFile.ReadOnly = true;
            this.textBox_wiitdbTextFile.Size = new System.Drawing.Size(301, 20);
            this.textBox_wiitdbTextFile.TabIndex = 15;
            this.textBox_wiitdbTextFile.TextChanged += new System.EventHandler(this.textBox_wiitdbTextFile_TextChanged);
            // 
            // btn_browse_wiitdbTextFile
            // 
            this.btn_browse_wiitdbTextFile.Location = new System.Drawing.Point(327, 39);
            this.btn_browse_wiitdbTextFile.Margin = new System.Windows.Forms.Padding(2);
            this.btn_browse_wiitdbTextFile.Name = "btn_browse_wiitdbTextFile";
            this.btn_browse_wiitdbTextFile.Size = new System.Drawing.Size(68, 24);
            this.btn_browse_wiitdbTextFile.TabIndex = 14;
            this.btn_browse_wiitdbTextFile.Text = "Browse...";
            this.btn_browse_wiitdbTextFile.UseVisualStyleBackColor = true;
            this.btn_browse_wiitdbTextFile.UseWaitCursor = true;
            this.btn_browse_wiitdbTextFile.Click += new System.EventHandler(this.btn_browse_wiitdbTextFile_Click);
            // 
            // btn_browse_destination
            // 
            this.btn_browse_destination.Location = new System.Drawing.Point(327, 103);
            this.btn_browse_destination.Margin = new System.Windows.Forms.Padding(2);
            this.btn_browse_destination.Name = "btn_browse_destination";
            this.btn_browse_destination.Size = new System.Drawing.Size(68, 24);
            this.btn_browse_destination.TabIndex = 17;
            this.btn_browse_destination.Text = "Browse...";
            this.btn_browse_destination.UseVisualStyleBackColor = true;
            this.btn_browse_destination.UseWaitCursor = true;
            this.btn_browse_destination.Click += new System.EventHandler(this.btn_browse_destination_Click);
            // 
            // textBox_destination
            // 
            this.textBox_destination.Location = new System.Drawing.Point(15, 105);
            this.textBox_destination.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_destination.Name = "textBox_destination";
            this.textBox_destination.ReadOnly = true;
            this.textBox_destination.Size = new System.Drawing.Size(301, 20);
            this.textBox_destination.TabIndex = 18;
            this.textBox_destination.TextChanged += new System.EventHandler(this.textBox_destination_TextChanged);
            // 
            // label_destination
            // 
            this.label_destination.AutoSize = true;
            this.label_destination.Location = new System.Drawing.Point(14, 81);
            this.label_destination.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_destination.Name = "label_destination";
            this.label_destination.Size = new System.Drawing.Size(140, 13);
            this.label_destination.TabIndex = 19;
            this.label_destination.Text = "Chose where the files will go";
            this.label_destination.UseWaitCursor = true;
            this.label_destination.Click += new System.EventHandler(this.label_destination_Click);
            // 
            // btn_downloadAllArts
            // 
            this.btn_downloadAllArts.Location = new System.Drawing.Point(15, 162);
            this.btn_downloadAllArts.Margin = new System.Windows.Forms.Padding(2);
            this.btn_downloadAllArts.Name = "btn_downloadAllArts";
            this.btn_downloadAllArts.Size = new System.Drawing.Size(380, 41);
            this.btn_downloadAllArts.TabIndex = 9;
            this.btn_downloadAllArts.Text = "Download Wii And GameCube Full Cover";
            this.btn_downloadAllArts.UseVisualStyleBackColor = true;
            this.btn_downloadAllArts.UseWaitCursor = true;
            this.btn_downloadAllArts.Click += new System.EventHandler(this.btn_downloadAllArts_Click);
            // 
            // DownloadWiiGameCubeArtHelper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 226);
            this.Controls.Add(this.btn_downloadAllArts);
            this.Controls.Add(this.btn_browse_destination);
            this.Controls.Add(this.textBox_destination);
            this.Controls.Add(this.label_destination);
            this.Controls.Add(this.btn_browse_wiitdbTextFile);
            this.Controls.Add(this.textBox_wiitdbTextFile);
            this.Controls.Add(this.label_wiitdbTextFile);
            this.Name = "DownloadWiiGameCubeArtHelper";
            this.Text = "Download Wii GameCube Full Cover Helper";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_wiitdbTextFile;
        private System.Windows.Forms.TextBox textBox_wiitdbTextFile;
        private System.Windows.Forms.Button btn_browse_wiitdbTextFile;
        private System.Windows.Forms.Button btn_browse_destination;
        private System.Windows.Forms.TextBox textBox_destination;
        private System.Windows.Forms.Label label_destination;
        private System.Windows.Forms.Button btn_downloadAllArts;
    }
}

