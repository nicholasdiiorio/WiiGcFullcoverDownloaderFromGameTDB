﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace GametdbWiiAndGcArtDownloader
{
    #region Serializable Structs
    [Serializable]
    public struct DownloadResult
    {
        public List<string> errorMessages;
    }
    #endregion

    public partial class DownloadWiiGameCubeArtHelper : Form
    {
        // Gametdb links
        private const string GAMETDB_DOWNLOAD_LINK_START = "https://art.gametdb.com/wii/coverfullHQ/US/";
        private const string GAMETDB_DOWNLOAD_LINK_END = ".png";

        //  UI texts
        private const string BUTTON_DOWNLOAD_TEXT = "Download Wii And GameCube Full Cover";
        private const string BUTTON_CANCEL_TEXT = "--- CANCEL DOWNLOAD ---";

        private enum DownloadButtonState { Download, Cancel }
        private DownloadButtonState downloadButtonState
        {
            get
            {
                switch (btn_downloadAllArts.Text)
                {
                    case BUTTON_DOWNLOAD_TEXT:
                        return DownloadButtonState.Download;

                    case BUTTON_CANCEL_TEXT:
                        return DownloadButtonState.Cancel;

                    default:
                        throw new ArgumentException();
                }
            }
            set
            {
                switch (value)
                {
                    case DownloadButtonState.Download:
                        btn_downloadAllArts.Text = BUTTON_DOWNLOAD_TEXT;
                        SetFormControlsEnabled(true);
                        break;

                    case DownloadButtonState.Cancel:
                        btn_downloadAllArts.Text = BUTTON_CANCEL_TEXT;
                        SetFormControlsEnabled(false);
                        break;

                    default:
                        throw new ArgumentException();
                }
            }
        }

        private bool cancelRequested = false;

        public DownloadWiiGameCubeArtHelper()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;

            downloadButtonState = DownloadButtonState.Download;
        }

        private void SetFormControlsEnabled(bool enabled)
        {
            textBox_wiitdbTextFile.Enabled = enabled;
            btn_browse_wiitdbTextFile.Enabled = enabled;

            textBox_destination.Enabled = enabled;
            btn_browse_destination.Enabled = enabled;
        }

        private void ShowFolderBrowserDialog(TextBox associatedTextBox, string description)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = description;
                folderBrowserDialog.SelectedPath = FindClosestValidDirectoryPath(associatedTextBox.Text);
                folderBrowserDialog.ShowNewFolderButton = true;

                DialogResult result = folderBrowserDialog.ShowDialog();
                if (result == DialogResult.OK)
                {
                    associatedTextBox.Text = folderBrowserDialog.SelectedPath;
                }
            }
        }

        private void ShowFileBrowserDialog(TextBox associatedTextBox, string description)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = description;
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = false;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    associatedTextBox.Text = openFileDialog.FileName;
                }
            }
        }

        private string FindClosestValidDirectoryPath(string path)
        {
            // If the directory path doesn't exist, go back up parent directories until a valid directory is found
            while (Directory.Exists(path) == false && path != string.Empty)
            {
                path = path.Remove(path.LastIndexOf('\\'));
            }

            return path;
        }

        private async void DownloadFilesToDestination()
        {
            // Change button state to Cancel & save original window title
            downloadButtonState = DownloadButtonState.Cancel;
            string window_originalTitle = this.Text;

            IEnumerable<string> titleCodeNames = GetAllTitleCodeNamesInWiitdbTxtFile();


            // Start the transfer of file (with progress updates)
            DownloadResult result = await DownloadFilesAsync(textBox_destination.Text, titleCodeNames, (current) =>
            {
                this.Text = $"Download in progress... {current}/{titleCodeNames.Count()} ({100 * current / titleCodeNames.Count()}%)";
            });

            // Change button state to Extract & restore original window title
            downloadButtonState = DownloadButtonState.Download;
            this.Text = window_originalTitle;

            // If the extraction was cancelled, stop here
            if (cancelRequested)
            {
                this.Enabled = true; // Form was Disabled after clicking Cancel, re-enable it
                cancelRequested = false;

                return;
            }

            // Output error log on the disk if needed
            if (result.errorMessages.Count > 0)
            {
                OutputErrorsToLog(result.errorMessages, textBox_destination.Text);
            }

            // Tell the user everything is done and let him know if anything went wrong
            if (result.errorMessages.Count == 0)
            {
                Show($"The download finished without any problem!.", MessageType.Success);
            }
            else
            {
                Show($"The download has encountered {result.errorMessages.Count} error(s).\n\nGo check errorLog.txt for more info.", MessageType.Error);
            }
        }

        private Uri uri = null;
        private WebClient client = null;
        private async Task<DownloadResult> DownloadFilesAsync(string destinationPath, IEnumerable<string> titleCodeNames, Action<int> progressUpdateCallback = null)
        {
            List<string> _errorMessages = new List<string>();

            progressUpdateCallback?.Invoke(0);

            Directory.CreateDirectory(destinationPath);

            for (int i = 0; i < titleCodeNames.Count(); i++)
            {
                string fileLink = $"{GAMETDB_DOWNLOAD_LINK_START}{titleCodeNames.ElementAt(i)}{GAMETDB_DOWNLOAD_LINK_END}";

                if (string.IsNullOrEmpty(fileLink) == false)
                {
                    uri = new Uri(fileLink);
                    client = new WebClient();

                    string downloadDestination = $"{destinationPath}\\{titleCodeNames.ElementAt(i)}{GAMETDB_DOWNLOAD_LINK_END}";

                    try
                    {
                        await client.DownloadFileTaskAsync(uri, $"{downloadDestination}");
                    }
                    catch (Exception e)
                    {
                        _errorMessages.Add($"{titleCodeNames.ElementAt(i)} error : {e.Message}");

                        if (File.Exists(downloadDestination))
                        {
                            File.Delete(downloadDestination);
                        }
                    };

                    uri = null;
                    client = null;
                }

                progressUpdateCallback?.Invoke(i);

                if (cancelRequested)
                    break;
            }

            return new DownloadResult()
            {
                errorMessages = _errorMessages
            };
        }

        private static Form topMostForm = new Form() { TopMost = true };
        public enum MessageType { Success, Error }
        public static DialogResult Show(string message, MessageType messageType)
        {
            switch (messageType)
            {
                case MessageType.Success:
                    return MessageBox.Show(topMostForm, message, "Nice!");

                case MessageType.Error:
                    return MessageBox.Show(topMostForm, message, "Damn!");

                default:
                    throw new Exception("DialogResult Show(string message, MessageType messageType) has received an invalid MessageType.");
            }
        }

        private void OutputErrorsToLog(List<string> errorMessages, string outputFolderPath)
        {
            string errorsOutputPath = $"{outputFolderPath}\\errorLog.txt";

            File.AppendAllLines(errorsOutputPath, errorMessages.Append(string.Empty));
        }

        private IEnumerable<string> GetAllTitleCodeNamesInWiitdbTxtFile()
        {
            // Load all lines from wiitdb text file
            string[] allLines = File.ReadAllLines(textBox_wiitdbTextFile.Text);

            // Remove the first line since it's not a game
            IEnumerable<string> allLinesWithoutFirst = allLines.Skip(1);

            // Remove all the junk after the ' =' to get only the game codes
            IEnumerable<string> allCodeNames = allLinesWithoutFirst.Select(l => l.Substring(0, l.IndexOf('=') - 1));

            return allCodeNames;
        }

        #region UIGeneratedFunction

        // wiitdbtextfile
        private void label_wiitdbTextFile_Click(object sender, EventArgs e)
        {

        }

        private void textBox_wiitdbTextFile_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_browse_wiitdbTextFile_Click(object sender, EventArgs e)
        {
            ShowFileBrowserDialog(textBox_wiitdbTextFile, label_wiitdbTextFile.Text);
        }

        // destination
        private void label_destination_Click(object sender, EventArgs e)
        {

        }

        private void textBox_destination_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_browse_destination_Click(object sender, EventArgs e)
        {
            ShowFolderBrowserDialog(textBox_destination, label_destination.Text);
        }

        // download
        private void btn_downloadAllArts_Click(object sender, EventArgs e)
        {
            switch (downloadButtonState)
            {
                case DownloadButtonState.Download:
                    btn_Transfer_OnClick(sender, e);
                    break;

                case DownloadButtonState.Cancel:
                    btn_Cancel_OnClick(sender, e);
                    break;

                default:
                    throw new ArgumentException();
            }
        }

        #endregion

        #region Own btn call
        private void btn_Transfer_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(textBox_wiitdbTextFile.Text) == false)
                    throw new Exception("WiidbTextFile could not be loaded, is the path valid?");

                if (Directory.Exists(textBox_destination.Text) == false)
                    throw new Exception("The distination could not be found, is the path valid?");

                DownloadFilesToDestination();
            }
            catch (Exception exception)
            {
                Show(exception.Message, MessageType.Error);
            }
        }

        private void btn_Cancel_OnClick(object sender, EventArgs e)
        {
            this.Text = $"Canceling...";
            cancelRequested = true;

            this.Enabled = false; // Form will be re-enabled by ExtractGPSDataToJSON() once then cancellation is complete
        }
        #endregion
    }
}
